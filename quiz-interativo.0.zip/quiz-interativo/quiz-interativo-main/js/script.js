const questions = [
    { question: "O que é um array?", options: ["Função", "Lista ordenada", "Condicional", "Operador"], correct: 1 },
    { question: "Como acessar o terceiro elemento de um array em JavaScript?", options: ["array[2]", "array(2)", "array{3}", "array[3]"], correct: 0 },
    { question: "O que faz o método push()?", options: ["Remove o primeiro elemento", "Adiciona ao final", "Ordena o array", "Inverte o array"], correct: 1 },
    { question: "Qual método remove o último elemento de um array?", options: ["shift()", "pop()", "splice()", "push()"], correct: 1 },
    { question: "Qual método transforma um array em string?", options: ["toString()", "join()", "concat()", "split()"], correct: 0 },
    { question: "O que faz o método splice()?", options: ["Divide o array", "Adiciona ou remove elementos", "Ordena o array", "Inverte os elementos"], correct: 1 },
    { question: "Qual método adiciona elementos ao início do array?", options: ["push()", "pop()", "shift()", "unshift()"], correct: 3 },
    { question: "O que significa array.length?", options: ["Número de métodos", "Número de elementos", "Índice final", "Valor do último item"], correct: 1 },
    { question: "O que faz o método indexOf()?", options: ["Remove o item", "Adiciona valor", "Retorna índice de um item", "Ordena array"], correct: 2 },
    { question: "O que faz o método reverse()?", options: ["Ordena crescente", "Remove duplicatas", "Inverte o array", "Divide o array"], correct: 2 },

    { question: "O que significa '===' em JavaScript?", options: ["Atribuição", "Igualdade fraca", "Igualdade estrita", "Erro de sintaxe"], correct: 2 },
    { question: "Qual operador representa OU lógico?", options: ["&&", "||", "!", "=="], correct: 1 },
    { question: "Qual comando repete um bloco até uma condição ser falsa?", options: ["if", "switch", "for", "while"], correct: 3 },
    { question: "O que faz a estrutura do..while?", options: ["Executa após condição", "Executa antes", "Nunca executa", "Só se condição for falsa"], correct: 0 },
    { question: "O que o operador '!' faz?", options: ["Concatena", "Nega", "Multiplica", "Divide"], correct: 1 },
    { question: "Qual estrutura representa decisão binária?", options: ["if-else", "loop", "function", "array"], correct: 0 },
    { question: "O que é uma função recursiva?", options: ["Chama a si mesma", "Cria arrays", "Testa condições", "Retorna strings"], correct: 0 },
    { question: "Como declarar um array vazio?", options: ["[]", "{}", "()", "''"], correct: 0 },
    { question: "Qual estrutura permite repetir com controle de índice?", options: ["if", "for", "switch", "case"], correct: 1 },
    { question: "O que o operador '%' retorna?", options: ["Divisão inteira", "Resto da divisão", "Multiplicação", "Expoente"], correct: 1 },

    { question: "Qual comando encerra um loop imediatamente?", options: ["continue", "break", "return", "exit"], correct: 1 },
    { question: "Qual comando pula para a próxima iteração do loop?", options: ["break", "return", "continue", "stop"], correct: 2 },
    { question: "O que faz array.sort() por padrão?", options: ["Ordena alfabeticamente", "Ordena por tamanho", "Ordena numericamente", "Não ordena"], correct: 0 },
    { question: "Qual método junta dois arrays?", options: ["concat()", "push()", "splice()", "merge()"], correct: 0 },
    { question: "O que array.includes(x) verifica?", options: ["Remove x", "Adiciona x", "Verifica se x está presente", "Ordena com x"], correct: 2 },
    { question: "Qual saída de `[1,2,3].join('-')`?", options: ["1 2 3", "1-2-3", "123", "1_2_3"], correct: 1 },
    { question: "Como criar uma função em JavaScript?", options: ["function nome()", "func nome()", "def nome()", "method nome()"], correct: 0 },
    { question: "O que é JSON?", options: ["Linguagem de script", "Estrutura de repetição", "Formato de dados", "Método de array"], correct: 2 },
    { question: "Qual método transforma string em array?", options: ["join()", "split()", "slice()", "map()"], correct: 1 },
    { question: "Qual método aplica uma função a cada item do array?", options: ["filter()", "reduce()", "forEach()", "map()"], correct: 3 },

    { question: "O que filter() retorna?", options: ["Novo array filtrado", "Array ordenado", "Objeto", "Booleano"], correct: 0 },
    { question: "Qual estrutura avalia múltiplas opções com cases?", options: ["switch", "if", "loop", "array"], correct: 0 },
    { question: "O que typeof retorna?", options: ["Valor da variável", "Tipo da variável", "Comprimento", "Índice"], correct: 1 },
    { question: "Qual a saída de `typeof []`?", options: ["object", "array", "list", "undefined"], correct: 0 },
    { question: "Qual método executa uma função e acumula valor?", options: ["map()", "reduce()", "filter()", "sort()"], correct: 1 },
    { question: "Qual valor de início de array[0]?", options: ["1", "0", "-1", "undefined"], correct: 1 },
    { question: "Qual é o tipo de `null` em JavaScript?", options: ["object", "null", "undefined", "boolean"], correct: 0 },
    { question: "Qual palavra-chave declara uma constante?", options: ["let", "var", "const", "define"], correct: 2 },
    { question: "O que significa NaN?", options: ["Novo número", "Não é número", "Negativo", "Nulo"], correct: 1 },
    { question: "Qual método transforma array em string separada por vírgulas?", options: ["join()", "split()", "toString()", "concat()"], correct: 2 }
];

let currentQuestion = 0;
let score = 0;
let timeLeft = 30;
let timerId = null;

document.addEventListener('DOMContentLoaded', () => {
    loadHighScore();
    loadQuestion();
});

function loadQuestion() {
    const questionEl = document.getElementById('question-text');
    const optionA = document.getElementById('option-a');
    const optionB = document.getElementById('option-b');
    const optionC = document.getElementById('option-c');
    const optionD = document.getElementById('option-d');
    const nextButton = document.getElementById('next-button');

    if (currentQuestion < questions.length) {
        const q = questions[currentQuestion];
        questionEl.textContent = q.question;
        optionA.textContent = `A: ${q.options[0]}`;
        optionB.textContent = `B: ${q.options[1]}`;
        optionC.textContent = `C: ${q.options[2]}`;
        optionD.textContent = `D: ${q.options[3]}`;

        // Resetar classes e habilitar botões
        [optionA, optionB, optionC, optionD].forEach(btn => {
            btn.classList.remove('correct', 'wrong');
            btn.disabled = false;
        });

        nextButton.disabled = true;
        timeLeft = 30;
        updateTimer();
        startTimer();
    } else {
        showResult();
    }
}

function startTimer() {
    if (timerId !== null) clearInterval(timerId);
    timeLeft = 30;
    updateTimer();
    timerId = setInterval(() => {
        timeLeft--;
        updateTimer();
        if (timeLeft <= 0) {
            clearInterval(timerId);
            timerId = null;
            navigator.vibrate(200); // Vibração quando o tempo acaba
            checkAnswer(-1); // Tempo esgotado
        }
    }, 1000);
}

function updateTimer() {
    const timerEl = document.getElementById('timer');
    timerEl.textContent = `${Math.max(0, timeLeft)}s`; // Evita números negativos
    if (timeLeft <= 5) {
        timerEl.classList.add('warning');
    } else {
        timerEl.classList.remove('warning');
    }
}

function checkAnswer(selectedIndex) {
    const correctIndex = questions[currentQuestion].correct;
    const optionButtons = [
        document.getElementById('option-a'),
        document.getElementById('option-b'),
        document.getElementById('option-c'),
        document.getElementById('option-d')
    ];

    // Desabilitar botões após resposta
    optionButtons.forEach(btn => btn.disabled = true);

    // Aplicar feedback visual
    optionButtons[correctIndex].classList.add('correct');
    if (selectedIndex !== -1 && selectedIndex !== correctIndex) {
        optionButtons[selectedIndex].classList.add('wrong');
        navigator.vibrate(200); // Vibração na resposta errada
    }

    // Atualizar pontuação e avançar
    if (selectedIndex === correctIndex) {
        score += 0.5;
        clearInterval(timerId);
        timerId = null;
        setTimeout(nextQuestion, 1000); // Avança automaticamente após 1 segundo
    } else {
        clearInterval(timerId);
        timerId = null;
        document.getElementById('next-button').disabled = false;
    }
}

function nextQuestion() {
    currentQuestion++;
    if (currentQuestion < questions.length) {
        loadQuestion();
    } else {
        showResult();
    }
}

function showResult() {
    document.getElementById('quiz-container').classList.add('hidden');
    const resultContainer = document.getElementById('result-container');
    resultContainer.classList.remove('hidden');
    document.getElementById('score-text').textContent = `Sua pontuação: ${score} de 20`;

    // Salvar maior pontuação
    const highScore = parseFloat(localStorage.getItem('highScore') || 0);
    if (score > highScore) {
        localStorage.setItem('highScore', score);
        resultContainer.innerHTML += `<p>Nova maior pontuação: ${score}!</p>`;
    } else {
        resultContainer.innerHTML += `<p>Maior pontuação anterior: ${highScore}</p>`;
    }
}

function loadHighScore() {
    const highScore = localStorage.getItem('highScore');
    if (highScore) {
        document.getElementById('result-container').innerHTML += `<p>Maior pontuação: ${highScore}</p>`;
    }
}

function restartQuiz() {
    currentQuestion = 0;
    score = 0;
    document.getElementById('quiz-container').classList.remove('hidden');
    document.getElementById('result-container').classList.add('hidden');
    loadQuestion();
}

// Adicionar eventos
document.getElementById('option-a').addEventListener('click', () => checkAnswer(0));
document.getElementById('option-b').addEventListener('click', () => checkAnswer(1));
document.getElementById('option-c').addEventListener('click', () => checkAnswer(2));
document.getElementById('option-d').addEventListener('click', () => checkAnswer(3));